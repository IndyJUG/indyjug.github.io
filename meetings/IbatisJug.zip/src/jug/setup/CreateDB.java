package jug.setup;

import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.ibatis.common.jdbc.ScriptRunner;
import com.ibatis.common.resources.Resources;

public class CreateDB {

    public static void main(String[] args) {
        Connection connection = null;
        
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            connection = DriverManager.getConnection("jdbc:derby:/derby_databases/jug;create=true");
            Reader reader = Resources.getResourceAsReader("jug/setup/CreateDB.sql");

            ScriptRunner runner = new ScriptRunner(connection, false, false);
            runner.setLogWriter(null);
            runner.setErrorLogWriter(null);

            runner.runScript(reader);
            connection.commit();
            reader.close();
        } catch (Exception e)  {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
    }
    
    private static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                // ignore
                ;
            }
        }
    }
}
