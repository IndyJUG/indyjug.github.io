create schema jug;

create table jug.movie (
  movie_id int not null generated always as identity,
  name varchar(30),
  plot_summary varchar(100),
  release_date date,
  primary key (movie_id)
);

create table jug.award (
  award_id int not null generated always as identity,
  description varchar(30),
  primary key (award_id)
);

create table jug.movie_award (
  movie_id int not null,
  award_id int not null,
  primary key (movie_id, award_id),
  foreign key (movie_id) references jug.movie (movie_id),
  foreign key (award_id) references jug.award (award_id)
);
