package jug.test;

import java.util.List;

import jug.domain.MovieAward;

public class MovieAwardDAOTest extends BaseIbatisTest {
    public void testInsert() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Actor");
        movieAwardDAO.insertMovieAward(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);
        
        MovieAward returnedAward = movieAwardDAO.findMovieAward(newId);
        assertEquals(newId, returnedAward.getId());
        assertEquals(movieAward.getDescription(), returnedAward.getDescription());
    }

    public void testUpdate() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Acter");
        movieAwardDAO.insertMovieAward(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);
        
        movieAward.setDescription("Best Actor");
        movieAwardDAO.updateMovieAward(movieAward);
        
        MovieAward returnedAward = movieAwardDAO.findMovieAward(newId);
        assertEquals(newId, returnedAward.getId());
        assertEquals(movieAward.getDescription(), returnedAward.getDescription());
    }

    public void testDelete() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Actor");
        movieAwardDAO.insertMovieAward(movieAward);
        
        movieAward = new MovieAward();
        movieAward.setDescription("Best Actress");
        movieAwardDAO.insertMovieAward(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);
        
        List<MovieAward> list = movieAwardDAO.findAllMovieAwards();
        assertEquals(2, list.size());
        
        movieAwardDAO.deleteMovieAward(newId);
        
        list = movieAwardDAO.findAllMovieAwards();
        assertEquals(1, list.size());
    }
}
