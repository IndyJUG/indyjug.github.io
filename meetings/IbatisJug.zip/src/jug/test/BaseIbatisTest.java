package jug.test;

import java.io.Reader;
import java.sql.Connection;

import javax.sql.DataSource;

import jug.dao.MovieAwardDAO;
import jug.dao.MovieAwardDAOIbatisImpl;
import jug.dao.MovieDAO;
import jug.dao.MovieDAOIbatisImpl;
import junit.framework.TestCase;

import com.ibatis.common.jdbc.ScriptRunner;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public abstract class BaseIbatisTest extends TestCase {
    
    protected SqlMapClient sqlMapClient;
    protected MovieDAO movieDAO;
    protected MovieAwardDAO movieAwardDAO;

    public BaseIbatisTest() {
        try {
            // build the SQL Map Client
            Reader reader = Resources.getResourceAsReader("jug/test/SqlMapConfig.xml");
            sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(reader);
            reader.close();

            // build the DAOs
            movieDAO = new MovieDAOIbatisImpl(sqlMapClient);
            movieAwardDAO = new MovieAwardDAOIbatisImpl(sqlMapClient);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    protected void setUp() throws Exception {
        // clear the database before every test
        DataSource ds = sqlMapClient.getDataSource();
        Connection conn = ds.getConnection();
        Reader reader = Resources.getResourceAsReader("jug/test/ClearDB.sql");
        ScriptRunner runner = new ScriptRunner(conn, false, false);
        runner.setLogWriter(null);
        runner.setErrorLogWriter(null);
        runner.runScript(reader);
        conn.commit();
        conn.close();
        reader.close();
    }
}
