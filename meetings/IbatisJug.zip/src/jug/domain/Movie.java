package jug.domain;

import java.util.Date;
import java.util.List;

public class Movie {
    private Integer id;

    private String name;

    private String plotSummary;

    private Date releaseDate;

    private List<MovieAward> awards;

    public List<MovieAward> getAwards() {
        return awards;
    }

    public void setAwards(List<MovieAward> awards) {
        this.awards = awards;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getPlotSummary() {
        return plotSummary;
    }

    public void setPlotSummary(String plotSummary) {
        this.plotSummary = plotSummary;
    }
}
