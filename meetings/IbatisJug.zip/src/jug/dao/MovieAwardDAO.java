package jug.dao;

import java.util.List;

import jug.domain.MovieAward;

public interface MovieAwardDAO {
    Integer insertMovieAward(MovieAward movieAward);

    void updateMovieAward(MovieAward movieAward);

    void deleteMovieAward(Integer id);

    MovieAward findMovieAward(Integer id);

    List<MovieAward> findAllMovieAwards();
}
