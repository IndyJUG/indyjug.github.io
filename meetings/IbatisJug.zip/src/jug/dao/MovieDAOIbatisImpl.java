package jug.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.sqlmap.client.SqlMapClient;

import jug.domain.Movie;
import jug.domain.MovieAward;
import jug.domain.MovieSearchCriteria;

public class MovieDAOIbatisImpl implements MovieDAO {
    private SqlMapClient sqlMapClient;

    public MovieDAOIbatisImpl(SqlMapClient sqlMapClient) {
        this.sqlMapClient = sqlMapClient;
    }

    public void deleteMovie(Integer id) {
        try {
            sqlMapClient.delete("MovieDAO.deleteAllMovieAwards", id);
            sqlMapClient.delete("MovieDAO.deleteMovie", id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Movie findMovie(Integer id) {
        try {
            return (Movie) sqlMapClient.queryForObject("MovieDAO.findMovie", id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findMovies(MovieSearchCriteria movieSearchCriteria) {
        try {
            return sqlMapClient.queryForList("MovieDAO.findMoviesByCriteria", movieSearchCriteria);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Integer insertMovie(Movie movie) {
        try {
            Integer movieId = (Integer) sqlMapClient.insert("MovieDAO.insertMovie", movie);
            
            if (movie.getAwards() != null) {
                Map<String, Integer> parms = new HashMap<String, Integer>();
                parms.put("movie_id", movieId);
                for (MovieAward movieAward : movie.getAwards()) {
                    parms.put("award_id", movieAward.getId());
                    sqlMapClient.insert("MovieDAO.insertMovieAward", parms);
                }
            }
            return movieId;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateMovie(Movie movie) {
        try {
            sqlMapClient.update("MovieDAO.updateMovie", movie);
            sqlMapClient.delete("MovieDAO.deleteAllMovieAwards", movie.getId());
            
            if (movie.getAwards() != null) {
                Map<String, Integer> parms = new HashMap<String, Integer>();
                parms.put("movie_id", movie.getId());
                for (MovieAward movieAward : movie.getAwards()) {
                    parms.put("award_id", movieAward.getId());
                    sqlMapClient.insert("MovieDAO.insertMovieAward", parms);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findAllMovies() {
        try {
            return sqlMapClient.queryForList("MovieDAO.findMovie");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findMovies(List<Integer> ids) {
        try {
            return sqlMapClient.queryForList("MovieDAO.findMoviesByIds", ids);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
