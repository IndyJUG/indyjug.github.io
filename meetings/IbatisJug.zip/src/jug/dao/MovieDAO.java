package jug.dao;

import java.util.List;

import jug.domain.Movie;
import jug.domain.MovieSearchCriteria;

public interface MovieDAO {
    Integer insertMovie(Movie movie);

    void updateMovie(Movie movie);

    void deleteMovie(Integer id);

    Movie findMovie(Integer id);

    List<Movie> findMovies(MovieSearchCriteria movieSearchCriteria);
    
    List<Movie> findAllMovies();

    List<Movie> findMovies(List<Integer> ids);
}
