package jug.dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import jug.domain.MovieAward;

public class MovieAwardDAOIbatisImpl implements MovieAwardDAO {

    private SqlMapClient sqlMapClient;

    public MovieAwardDAOIbatisImpl(SqlMapClient sqlMapClient) {
        super();
        this.sqlMapClient = sqlMapClient;
    }

    public void deleteMovieAward(Integer id) {
        try {
            sqlMapClient.delete("MovieAwardDAO.deleteMovieAward", id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public List<MovieAward> findAllMovieAwards() {
        try {
            return sqlMapClient.queryForList("MovieAwardDAO.findAllMovieAwards");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public MovieAward findMovieAward(Integer id) {
        try {
            return (MovieAward) sqlMapClient.queryForObject(
                    "MovieAwardDAO.findMovieAward", id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Integer insertMovieAward(MovieAward movieAward) {
        try {
            return (Integer) sqlMapClient.insert(
                    "MovieAwardDAO.insertMovieAward", movieAward);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateMovieAward(MovieAward movieAward) {
        try {
            sqlMapClient.update("MovieAwardDAO.updateMovieAward", movieAward);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
