package jug.abator.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jug.abator.domain.Movie;
import jug.abator.domain.MovieSearchCriteria;
import jug.abator.generated.domain.MovieAward;

public class AbatorMovieDAOTest extends BaseAbatorSpringTest {

    public void testGroupBy() throws SQLException {
        MovieAward bestPicture = new MovieAward();
        bestPicture.setDescription("Best Picture");
        movieAwardDAO.insert(bestPicture);
        
        MovieAward bestDirector = new MovieAward();
        bestDirector.setDescription("Best Director");
        movieAwardDAO.insert(bestDirector);
        
        MovieAward bestActor = new MovieAward();
        bestActor.setDescription("Best Actor");
        movieAwardDAO.insert(bestActor);
        
        MovieAward bestActress = new MovieAward();
        bestActress.setDescription("Best Actress");
        movieAwardDAO.insert(bestActress);
        
        Movie departed = new Movie();
        departed.setName("The Departed");
        departed.setPlotSummary("No one's good, everyone dies");
        departed.setReleaseDate(new Date());
        departed.setAwards(new ArrayList<MovieAward>());
        departed.getAwards().add(bestPicture);
        departed.getAwards().add(bestDirector);
        insertMovie(departed);
        
        Movie lastKing = new Movie();
        lastKing.setName("The Last King of Scotland");
        lastKing.setPlotSummary("Idi Amin was a bad and crazy dude");
        lastKing.setReleaseDate(new Date());
        lastKing.setAwards(new ArrayList<MovieAward>());
        lastKing.getAwards().add(bestActor);
        insertMovie(lastKing);
        
        Movie queen = new Movie();
        queen.setName("The Queen");
        queen.setPlotSummary("She knows her people");
        queen.setReleaseDate(new Date());
        queen.setAwards(new ArrayList<MovieAward>());
        queen.getAwards().add(bestActress);
        insertMovie(queen);
        
        Movie cars = new Movie();
        cars.setName("Cars");
        cars.setPlotSummary("Romance in the auto world");
        cars.setReleaseDate(new Date());
        insertMovie(cars);
        
        List<Movie> movies = movieDAO.findAllMovies();
        assertEquals(4, movies.size());
        Movie movie = movies.get(0);
        assertEquals("Cars", movie.getName());
        assertEquals(0, movie.getAwards().size());
        
        movie = movies.get(1);
        assertEquals("The Departed", movie.getName());
        assertEquals(2, movie.getAwards().size());
        
        movie = movies.get(2);
        assertEquals("The Last King of Scotland", movie.getName());
        assertEquals(1, movie.getAwards().size());
        
        movie = movies.get(3);
        assertEquals("The Queen", movie.getName());
        assertEquals(1, movie.getAwards().size());

        // try criteria search
        MovieSearchCriteria criteria = new MovieSearchCriteria();
        criteria.setNamePattern("The%");
        movies = movieDAO.findMovies(criteria);
        assertEquals(3, movies.size());
        
        // try searching by a list of IDs
        List<Integer> ids = new ArrayList<Integer>();
        ids.add(queen.getId());
        ids.add(departed.getId());
        movies = movieDAO.findMovies(ids);
        assertEquals(2, movies.size());
        
        // try deleting a movie
        deleteMovie(queen.getId());
        movies = movieDAO.findAllMovies();
        assertEquals(3, movies.size());
    }

    /**
     * Normally, transactions would be controlled in a service layer,
     * this will suffice for testing.
     * 
     * @param movie
     * @throws SQLException
     */
    private void insertMovie(Movie movie) throws SQLException {
        try {
            sqlMapClient.startTransaction();
            movieDAO.insertMovie(movie);
            sqlMapClient.commitTransaction();
        } finally {
            sqlMapClient.endTransaction();
        }
    }

    /**
     * Normally, transactions would be controlled in a service layer,
     * this will suffice for testing.
     * 
     * @param movie
     * @throws SQLException
     */
    private void deleteMovie(Integer movieId) throws SQLException {
        try {
            sqlMapClient.startTransaction();
            movieDAO.deleteMovie(movieId);
            sqlMapClient.commitTransaction();
        } finally {
            sqlMapClient.endTransaction();
        }
    }
}
