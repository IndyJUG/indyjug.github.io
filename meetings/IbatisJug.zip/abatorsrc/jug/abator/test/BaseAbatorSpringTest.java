package jug.abator.test;

import java.io.Reader;
import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.ibatis.common.jdbc.ScriptRunner;
import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;

import jug.abator.dao.MovieDAO;
import jug.abator.generated.dao.MovieAwardDAO;
import junit.framework.TestCase;

public abstract class BaseAbatorSpringTest extends TestCase {
    
    protected MovieAwardDAO movieAwardDAO;
    protected MovieDAO movieDAO;
    protected BeanFactory beanFactory;
    protected SqlMapClient sqlMapClient;

    public BaseAbatorSpringTest() {
        ClassPathResource res = new ClassPathResource("jug/abator/test/beans.xml");
        beanFactory = new XmlBeanFactory(res);
        movieAwardDAO = (MovieAwardDAO) beanFactory.getBean("MovieAwardDAO");
        movieDAO = (MovieDAO) beanFactory.getBean("MovieDAO");
        sqlMapClient = (SqlMapClient) beanFactory.getBean("sqlMapClient");
    }

    @Override
    protected void setUp() throws Exception {
        // clear the database before every test
        DataSource ds = (DataSource) beanFactory.getBean("dataSource");
        Connection conn = ds.getConnection();
        Reader reader = Resources.getResourceAsReader("jug/test/ClearDB.sql");
        ScriptRunner runner = new ScriptRunner(conn, false, false);
        runner.setLogWriter(null);
        runner.setErrorLogWriter(null);
        runner.runScript(reader);
        conn.commit();
        conn.close();
        reader.close();
    }
}
