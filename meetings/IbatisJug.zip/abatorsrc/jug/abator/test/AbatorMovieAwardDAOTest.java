package jug.abator.test;

import java.util.List;

import jug.abator.generated.domain.MovieAward;
import jug.abator.generated.domain.MovieAwardExample;

public class AbatorMovieAwardDAOTest extends BaseAbatorSpringTest {
    public void testInsert() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Actor");
        movieAwardDAO.insert(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);
        
        MovieAward returnedAward = movieAwardDAO.selectByPrimaryKey(newId);
        assertEquals(newId, returnedAward.getId());
        assertEquals(movieAward.getDescription(), returnedAward.getDescription());
    }

    public void testUpdate() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Acter");
        movieAwardDAO.insert(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);
        
        movieAward.setDescription("Best Actor");
        movieAwardDAO.updateByPrimaryKey(movieAward);
        
        MovieAward returnedAward = movieAwardDAO.selectByPrimaryKey(newId);
        assertEquals(newId, returnedAward.getId());
        assertEquals(movieAward.getDescription(), returnedAward.getDescription());
    }

    public void testDelete() {
        MovieAward movieAward = new MovieAward();
        movieAward.setDescription("Best Actor");
        movieAwardDAO.insert(movieAward);
        
        movieAward = new MovieAward();
        movieAward.setDescription("Best Actress");
        movieAwardDAO.insert(movieAward);
        
        Integer newId = movieAward.getId();
        assertNotNull(newId);

        MovieAwardExample example = new MovieAwardExample();
        List<MovieAward> list = movieAwardDAO.selectByExample(example);
        assertEquals(2, list.size());
        
        movieAwardDAO.deleteByPrimaryKey(newId);
        
        list = movieAwardDAO.selectByExample(example);
        assertEquals(1, list.size());
    }
}
