delete from jug.movie_award;
delete from jug.movie;
delete from jug.award;
