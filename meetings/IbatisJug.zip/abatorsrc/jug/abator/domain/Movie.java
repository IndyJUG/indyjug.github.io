package jug.abator.domain;

import java.util.List;

import jug.abator.generated.domain.BasicMovie;
import jug.abator.generated.domain.MovieAward;

public class Movie extends BasicMovie {
    private List<MovieAward> awards;

    public List<MovieAward> getAwards() {
        return awards;
    }

    public void setAwards(List<MovieAward> awards) {
        this.awards = awards;
    }
}
