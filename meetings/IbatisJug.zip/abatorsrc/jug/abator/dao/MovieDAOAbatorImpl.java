package jug.abator.dao;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import jug.abator.domain.Movie;
import jug.abator.domain.MovieSearchCriteria;
import jug.abator.generated.dao.BasicMovieDAO;
import jug.abator.generated.dao.MovieAwardLinkDAO;
import jug.abator.generated.domain.BasicMovieExample;
import jug.abator.generated.domain.MovieAward;
import jug.abator.generated.domain.MovieAwardLink;
import jug.abator.generated.domain.MovieAwardLinkExample;

public class MovieDAOAbatorImpl extends SqlMapClientDaoSupport implements MovieDAO {
    
    private MovieAwardLinkDAO movieAwardLinkDAO;
    private BasicMovieDAO basicMovieDAO;

    public void deleteMovie(Integer id) {
        // delete awards...
        deleteMovieAwards(id);
        
        // delete movie...
        BasicMovieExample basicMovieExample = new BasicMovieExample();
        basicMovieExample.createCriteria().andIdEqualTo(id);
        basicMovieDAO.deleteByExample(basicMovieExample);
    }

    private void deleteMovieAwards(Integer id) {
        MovieAwardLinkExample movieAwardLinkExample = new MovieAwardLinkExample();
        movieAwardLinkExample.createCriteria().andMovieIdEqualTo(id);
        
        
        movieAwardLinkDAO.deleteByExample(movieAwardLinkExample);
    }

    public Movie findMovie(Integer id) {
        return (Movie) getSqlMapClientTemplate().queryForObject("MovieDAO.findMovie", id);
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findMovies(MovieSearchCriteria movieSearchCriteria) {
        return getSqlMapClientTemplate().queryForList("MovieDAO.findMoviesByCriteria", movieSearchCriteria);
    }

    /**
     * This method is a bit of a get/set dance.  But this may
     * be worth it to be able to use generated code, and there
     * is often more information in the actual record than
     * what is in the domain object.
     */
    public Integer insertMovie(Movie movie) {
        Integer movieId = basicMovieDAO.insert(movie);
        movie.setId(movieId);
        
        if (movie.getAwards() != null) {
            MovieAwardLink movieAwardLink = new MovieAwardLink();
            movieAwardLink.setMovieId(movieId);
            for (MovieAward movieAward : movie.getAwards()) {
                movieAwardLink.setAwardId(movieAward.getId());
                movieAwardLinkDAO.insert(movieAwardLink);
            }
        }
        
        return movieId;
    }

    public void updateMovie(Movie movie) {
        basicMovieDAO.updateByPrimaryKey(movie);
        
        deleteMovieAwards(movie.getId());
        
        if (movie.getAwards() != null) {
            MovieAwardLink movieAwardLink = new MovieAwardLink();
            movieAwardLink.setMovieId(movie.getId());
            for (MovieAward movieAward : movie.getAwards()) {
                movieAwardLink.setAwardId(movieAward.getId());
                movieAwardLinkDAO.insert(movieAwardLink);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findAllMovies() {
        return getSqlMapClientTemplate().queryForList("MovieDAO.findMovie");
    }

    @SuppressWarnings("unchecked")
    public List<Movie> findMovies(List<Integer> ids) {
        return getSqlMapClientTemplate().queryForList("MovieDAO.findMoviesByIds", ids);
    }

    /**
     * Setter for Spring
     * 
     * @param basicMovieDAO
     */
    public void setBasicMovieDAO(BasicMovieDAO basicMovieDAO) {
        this.basicMovieDAO = basicMovieDAO;
    }

    /**
     * Setter for Spring
     * 
     * @param movieAwardLinkDAO
     */
    public void setMovieAwardLinkDAO(MovieAwardLinkDAO movieAwardLinkDAO) {
        this.movieAwardLinkDAO = movieAwardLinkDAO;
    }
}
