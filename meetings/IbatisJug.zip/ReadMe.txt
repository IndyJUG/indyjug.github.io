/*
 *  Copyright 2007 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

This zip contains code to be demonstrated at a typical user's group
presentation.  If you are using Eclipse, then you can simply unzip the
file to some convenient location and them import the "IbatisJug" project.

Else...compile the source tree in the /src directory and the /abatorsrc directory.
   The following JARs are necessary for compile:
   
   spring.jar (I used the composite Spring JAR for simplicity)
   An iBATIS JAR (I used ibatis-2.3.0.677.jar)
   junit.jar

Note the the code is written for Java 5!!!
   
Running the demos:

1. Create a directory /derby_databases
2. Run the program jug.setup.CreateDB - this will create the derby database
   used for testing.  You will need to make sure that derby.jar
   is in the runtime classpath for this program.
3. All the base iBATIS demos are in the package jug.test
   Again, make sure that derby.jar is in the runtime classpath.
4. The build.xml in the jug.abator package is used to run Abator to generate
   code against the sample database.
5. The Spring/Abator/iBATIS demos are in the package jug.abator.test
   Again, make sure that derby.jar is in the runtime classpath.
   