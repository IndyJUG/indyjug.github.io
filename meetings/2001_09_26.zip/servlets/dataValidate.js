var ssnPattern   = /^[0-9]{3}+-+[0-9]{2}+-+[0-9]{4}$/
var phonePattern = /^\([0-9]{3}\)[0-9]{3}+-+[0-9]{4}$/
var datePattern  = /^[0-9]{2}+\/+[0-9]{2}+\/+[1|2][0-9]{3}$/
var namePattern  = /^[A-Z][a-z]+\s+[A-Z][a-z]+$/

function validate() 
{
    if (   checkName(document.testForm.NAME.value)
        && checkSSN(document.testForm.SSN.value)
        && checkPhone(document.testForm.PHONE.value)
        && checkDate(document.testForm.DATE.value)
       )
       {
           return true;
       }
    else 
       {
           alert("Some field is not right");
	     return false;
       }
}

function checkEmail(email) 
{
    var emailPattern = /^.+\@.+\..+$/;
    if (emailPattern.test(email))
        return true;
    else
        return false;
}
		
function checkSSN(name) 
{
    return checkField(name, ssnPattern);
}
	    
function checkPhone(name) 
{
    return checkField(name, phonePattern);
}
	    
function checkDate(name) 
{
    return checkField(name, datePattern);
}

function checkName(name) 
{
    return checkField(name, namePattern);
}
	    
function checkField(name, pattern) 
{
    if(pattern.test(name))
        return true;
    else 
        return false;
}

