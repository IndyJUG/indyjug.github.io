
/**
 * This class represents a data validating item
 *
 * @author: Wei Li, 09/2001
 * @version: 
 */
public class Item {
    
    // fields wraps a data validator
    private String name;
    private String pattern;
    private boolean validate;
    private String sample;
    private String explanation;

    /**
     * Constructor
     */
    public Item () {

    }

    /**
     * Sets the name for the validating item
     *
     * @param name the name of the validating item
     */
    public void setName (String name) {
        this.name = name;
    }

    /**
     * Returns the name of the data validating item
     *
     * @return the name of the data validating item
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the pattern to validate data
     *
     * @param pattern the pattern used to validate data
     */
    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    /**
     * Returns the pattern to validate data
     *
     * @return the pattern to validate data
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Sets whether the data will be validated or not
     *
     * @param check a String. If "yes", validate the data. 
     */
    public void setValidate(String check) {
        if (check.equalsIgnoreCase("yes")) {
            validate = true;
        } else {
            validate = false;
        }
    }

    /**
     * Returns the indication whether the data will be 
     * or not
     *
     * @return true if the data will be validated
     */
    public boolean getValidate() {
        return validate;
    }

    /**
     * Sets the sample of a valid data
     *
     * @param sample a String representing a valid data
     */
    public void setSample (String sample) {
        this.sample = sample;
    }

    /**
     * Returns the sample of the valid data 
     *
     * @return the sample of the valid data
     */
    public String getSample() {
        return sample;
    }

    /**
     * Sets the explanation for the validatiion
     *
     * @param explanation a String explaining 
     *        what is a valid data
     */
    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    /**
     * Returns the explanation for the validation
     *
     * @return the explanation for the validation
     */
    public String getExplanation() {
        return explanation;
    }
    
    /**
     * a dirty web presentation
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("========<br>");
        sb.append("Field Name = " + name + "<br>");
        //sb.append("pattern = " + pattern + "<br>");
        sb.append("Sample = " + sample + "<br>");
        String check = validate? "yes":"no";
        //sb.append("check = " + check + "<br>");
        sb.append("Explanation = " + explanation + "<br>");
        return sb.toString();
    }

}
