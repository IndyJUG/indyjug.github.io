import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.stevesoft.pat.*;

/**
 * This class contains some static methods which  
 * retrieve html form data and validate it. The 
 * pattern used to validate the data is stored in
 * a xml file.
 * Some methods or some blocks may need to be 
 * synchronized in for thread-safe sake.
 *
 * @author: Wei Li, 09/2001
 * @version: 
 */
public class DataValidateUtils3 {

    /**
     * Nobody can instantiate me
     */
    private DataValidateUtils3 () {

    }

    /**
     * Obtains all parameters from given the request
     *
     * @param request an object of HpptServletRequest
     * @return a vector containing objects of HtmlField
     */
    private static Vector getParameterFromHtml(HttpServletRequest request){
        HashMap parameterMap = new HashMap();
        Vector htmlFieldVector = new Vector();
        for(Enumeration e = request.getParameterNames(); e.hasMoreElements();){
            String fieldName = (String)e.nextElement();
            //if(!fieldName.endsWith("_PATTERN") ){
                HtmlField htmlField = new HtmlField();
                htmlField.setFieldName(fieldName);
                htmlField.setFieldValue(request.getParameter(fieldName));
                htmlField.setFieldPattern(request.getParameter(fieldName + "_PATTERN"));
                htmlFieldVector.add(htmlField);
            //}
        }
        return htmlFieldVector;
    }

    /**
     * Validate the html form and return a vector containing
     * the objects of the invalid items.
     *
     * @param request an object of HttpServletRequet 
     * @return a vector containing the objects of the invalid items
     */
    public static Vector validateHtmlForm (HttpServletRequest request, Map itemMap){
        Vector htmlFieldVector = getParameterFromHtml(request);
        Vector invalidField = new Vector();
        for(Iterator it = htmlFieldVector.iterator(); it.hasNext();){
            HtmlField htmlField = (HtmlField)it.next();
            Item item = (Item)itemMap.get(htmlField.getFieldName());
            if(item != null && !validate(htmlField, item)){
                invalidField.add(item);
            }
        }		
        return invalidField;
    }

    /**
     * Validate the value wrapped in an HtmlField object
     * using the validating item
     *
     * @param field an object of HtmlField which wraps a 
     *              html parameter
     * @patam item the validating item
     * @return true if the value wrapped is valid or it does 
     *         need to be validated
     */
    public static boolean validate(HtmlField field, Item item){
        String fieldValue = field.getFieldValue();
        String pattern    = item.getPattern();
                
        if (pattern == null) {
            return true;
        }
        if (fieldValue == null || (fieldValue.trim()).length() == 0) {
			return false;
        }
        if (item.getValidate()) {
            Regex r = new Regex(pattern);
            return r.matchAt(fieldValue, 0);
        } else {
            return true;
        }
    }

}




