/**
 * This class represents a html field.
 *
 * @author: Wei Li, 09/2001
 * @version: 
 */
class HtmlField{

    // fields wraps a html field
    private String fieldName;
    private String fieldValue;
    private String fieldPattern;
    private boolean isValid;

    /**
     * Sets the name for the field
     *
     * @param fieldName the name of the field
     */
    public void setFieldName (String fieldName){
        this.fieldName = fieldName; 
    }

    /**
     * Returns the name for the field
     *
     * @return the name of the field
     */
    public String getFieldName(){
        return fieldName;
    }

    /**
     * Sets the value of the field
     *
     * @param fieldValue the value of the field
     */
    public void setFieldValue (String fieldValue){
        this.fieldValue = fieldValue; 
    }

    /**
     * Returns the value of the field
     *
     * @return the value of the field
     */
    public String getFieldValue(){
        return fieldValue;
    }

    /**
     * Sets the pattern used to validate the value of 
     * this field
     *
     * @param fieldPattern the pattern to validate data
     */
    public void setFieldPattern (String fieldPattern){
        this.fieldPattern = fieldPattern; 
    }

    /**
     * Returns the pattern used to validate the value 
     * of this field
     *
     * @return the pattern to validate data
     */
    public String getFieldPattern(){
        return fieldPattern;
    }

    /**
     * Sets whether the data is valid or not
     *
     * @param isValid true if the data id valid
     */
    public void setIsValid(boolean isValid){
        this.isValid = isValid;
    }

    /**
     * Returns the indication whether the field value
     * is valid or not
     *
     * @return true if the field value is valid
     */
    public boolean getIsValid(){
        return isValid;
    }

}
	
