import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import com.sun.xml.tree.*;

/**
 * This class containing some static methods dealing
 * with xml. This class is borrowed from Nazmul Idris
 * and modified by Wei Li.
 *
 * @author: Nazmul Idris
 * @version: 
 */
public class XmlUtils{

    public static final String ROOT_ELEMENT_TAG = "ITEM";
    public static final String NAME             = "NAME";
    public static final String VALIDATE         = "VALIDATE";
    public static final String PATTERN          = "PATTERN";
    public static final String SAMPLE           = "SAMPLE";
    public static final String EXPLANATION      = "EXPLANATION";
    
    /**
     * Nobody can instantiate me
     */
    private XmlUtils(){

    }

    /**
     * Obtains a map containing "Name-Item" pairs
     * from a xml file
     *
     * @param fileName the path to the xml file
     * @return a map containing "Name-Item" pair
     */
    public static Map getItemMap(String fileName){
	  Map itemMap = new HashMap();
        Item item;
        try {
            InputStream is = new FileInputStream(fileName);
            Document doc = XmlDocument.createXmlDocument(is, true);
            int size = XmlUtils.getSize(doc, ROOT_ELEMENT_TAG);

            for ( int i = 0; i < size; i++ ) {
                item = new Item();
                Element row = XmlUtils.getElement(doc , ROOT_ELEMENT_TAG , i);
                item.setName(XmlUtils.getValue(row , NAME));
                item.setValidate(XmlUtils.getValue(row , VALIDATE));
                item.setPattern(XmlUtils.getValue(row , PATTERN));
                item.setSample(XmlUtils.getValue(row , SAMPLE));
                item.setExplanation(XmlUtils.getValue(row , EXPLANATION));
                itemMap.put(item.getName(), item);
            }
        } catch (Exception e) {
            System.out.println(e);
            return itemMap;
        }
        return itemMap;
    }

    /**
     * Obtains an xml element. 
     *
     * @param doc an object of xml Documetn
     * @param tagName the name of a tag
     * @param index an index
     * @return a xml element
     */
    public static Element getElement(Document doc, String tagName , int index) {
        NodeList rows = doc.getDocumentElement().getElementsByTagName(tagName);
        return (Element)rows.item(index);
    }

    /**
     * Obtains the number of item in the xml document. 
     *
     * @param doc an object of xml Documetn
     * @param tagName the name of a tag
     * @return the number of item in the xml document. 
     */
    public static int getSize(Document doc,String tagName) {
        NodeList rows = doc.getDocumentElement().getElementsByTagName(tagName);
        return rows.getLength();
    }

    /**
     * Obtains the value of a node given the element and 
     * the name of the tag 
     *
     * @param e an element
     * @param tagName the name of a tag
     * @return the value of a node 
     */
    public static String getValue(Element e, String tagName) {
        try{
            NodeList elements = e.getElementsByTagName(tagName);
            Node node = elements.item(0);
            NodeList nodes = node.getChildNodes();
        
            String s;
            for( int i=0; i<nodes.getLength(); i++){
                s = ((Node)nodes.item( i )).getNodeValue().trim();
                if(s.equals("") || s.equals("\r")) {
                    continue;
                } else {
		    return s;
		}
            }
        } catch(Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }
        return null;
    }

}

