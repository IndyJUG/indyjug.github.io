import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.stevesoft.pat.*;

/**
 * a simple servlet for demo of implementation 1
 *
 * @author: Wei Li, 09/2001
 * @version: 
 */
public class TestDataValidateServlet1 extends HttpServlet {

    /**
     * Performs the initialization work.
     *
     * @param servletConfig
     * @exception ServletExcetption if something is wrong
     */
    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);   
    }

    /**
     * Handles a GET method. Simple calls doPost method.
     *
     * @param request - HTTP request
     * @patam response - HTTP response
     * @exception ServletExcetption and IOException 
     *            if something is wrong
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles a POST method. Simply send a confirm message 
     * indicating that all data is valid since it has been
     * validated by javascript at client side.
     *
     * @param request - HTTP request
     * @patam response - HTTP response
     * @exception ServletExcetption and IOException 
     *            if something is wrong
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String action = request.getParameter("action");

        if(action.equals("submit")){
            out.println("all fields are surely valid");
        }		
    }

    /**
     * do nothing
     */
    public void destroy(){

    }
    
}
