import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.stevesoft.pat.*;

/**
 * a simple servlet for demo of implementation 3
 *
 * @author: Wei Li
 * @version: 0.0.1 09/2000
 *
 */
public class TestDataValidateServlet3 extends HttpServlet {
   
    Map itemMap = new HashMap();
    
    /**
     * Performs the initialization work.
     *
     * @param servletConfig
     * @exception ServletExcetption if something is wrong
     */
    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);
	String xmlFileName = servletConfig.getInitParameter("xmlFile");
	itemMap = XmlUtils.getItemMap(xmlFileName);
    }

    /**
     * Handles a GET method. Simple calls doPost method.
     *
     * @param request - HTTP request
     * @patam response - HTTP response
     * @exception ServletExcetption and IOException 
     *            if something is wrong
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles a POST method. Validates the data sent from 
     * a html form and response the validating results.
     *
     * @param request - HTTP request
     * @patam response - HTTP response
     * @exception ServletExcetption and IOException 
     *            if something is wrong
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
        
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		if(action.equals("submit")){
			Vector invalidField =  DataValidateUtils3.validateHtmlForm(request, itemMap);
			if(invalidField.isEmpty()){
				out.println("all fields are valid");
			} else {
				out.println("the invalid fiels are:<br>");
				Iterator it = invalidField.iterator();
				while(it.hasNext()) {
				    out.println((Item)it.next());
				}
			}
		}
	}

    /**
     * do nothing
     */
    public void destroy(){

    } 

}
