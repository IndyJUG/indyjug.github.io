import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.stevesoft.pat.*;

/**
 * This class contains some static methods which  
 * retrieve html form data and validate it. The 
 * pattern used to validate the data is passed from
 * the html hidden fields.
 * 
 * Some methods or some blocks may need to be 
 * synchronized in for thread-safe sake.
 *
 * @author: Wei Li, 09/2001
 * @version: 
 */
public class DataValidateUtils2 {

    /**
     * Nobody can instantiate me
     */
    private DataValidateUtils2() {

    }

    /**
     * Obtains all parameters from given the request
     *
     * @param request an object of HpptServletRequest
     * @return a vector containing objects of HtmlField
     */
    private static Vector getParameterFromHtml(HttpServletRequest request) {
        HashMap parameterMap = new HashMap();
        Vector htmlFieldVector = new Vector();
        for (Enumeration e = request.getParameterNames(); e.hasMoreElements();) {
            String fieldName = (String)e.nextElement();
            if(!fieldName.endsWith("_PATTERN") ){
                HtmlField htmlField = new HtmlField();
                htmlField.setFieldName(fieldName);
                htmlField.setFieldValue(request.getParameter(fieldName));
		htmlField.setFieldPattern(request.getParameter(fieldName + "_PATTERN"));
                htmlFieldVector.add(htmlField);
            }
        }
        return htmlFieldVector;
    }

    /**
     * Validate the html form and return a vector containing
     * the names of the invalid fields.
     *
     * @param request an object of HttpServletRequet 
     * @return a vector containing the names of all invalid fields
     */
    public static Vector validateHtmlForm(HttpServletRequest request){
        Vector htmlFieldVector = getParameterFromHtml(request);
        Vector invalidField = new Vector();
        for (Iterator it = htmlFieldVector.iterator(); it.hasNext();) {
            HtmlField htmlField = (HtmlField)it.next();
            if (!validate(htmlField.getFieldPattern(), htmlField.getFieldValue())) {
                invalidField.add(htmlField.getFieldName());
            }
        }		
        return invalidField;
    }

    /**
     * Validates a value given the pattern
     *
     * @param patterm a String specifing the pattern
     *         used to validate the data
     * @param field a string which is the data to be validated
     * @return true if the data is valid 
     */
    public static boolean validate(String pattern, String field){
        if (pattern == null) {
            return true;
        }
        if (field == null || (field.trim()).length() == 0) {
            return false;
        }			
        Regex r = new Regex(pattern);
        return r.matchAt(field, 0);
    }

}




