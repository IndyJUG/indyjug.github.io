package timesocket;

/**
 * Title:  Time Socket Client
 * Description:  Connect to socket at "time-A.timefreq.bldrdoc.gov" port = 13
 * Copyright:    Copyright (c) 2003
 * Company:  Indianapolis Java User Group
 * @author Kurt Kirkham
 * @version 1.0
 */

import genericsocketserver.*;

public class TimeSocket {

  public static void main(String[] args) {

    // Create socket to host on port 13
    SocketWrapper swSocket = new SocketWrapper("time-A.timefreq.bldrdoc.gov", 13);

    String sTime = null;    // String to hold time
    boolean bDone = false;  // Boolean to indicate done

    // Loop until returns a null value.  First get is blank.
    while (!bDone)
    {
        // Get data from socket
        sTime = swSocket.getData();

        // If return is null set to stop processing
        if (sTime == null)
        {
           bDone = true;
        }
        else
        {
           // Print out result
           System.out.println("--> " + sTime);
        }
    }

    // Close socket
    swSocket.closeSocket();
  }
}