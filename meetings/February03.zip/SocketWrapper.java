package genericsocketserver;

/**
 * Title: SocketWrapper
 * Description: Wrapper for Socket to maintain socket state
 * Copyright:    Copyright (c) 2003
 * Company: Indianapolis Java User Group
 * @author Kurt Erik Kirkham
 * @version 1.0
 */

import java.io.*;
import java.net.*;

/**
 *  Socket Wrapper to wrap java.net.Socket
 */

public class SocketWrapper
{
    // Define Class variables
    private Socket m_sckSocket = null;            // Socket
    private BufferedReader m_brInput = null;      // Input from Buffered Reader Stream
    private PrintStream m_psOutput = null;        // Output to PrintStream
    private String m_sHost = "localhost";         // Host
    private int m_nPort = 1123;                   // Port
    private int m_nTimeout = 0;                   // Timeout

    /**
     * Constructor
     */

    public SocketWrapper()
    {

    }

    /**
     * Constructor - Saves socket passed and creates input and output steams
     *
     * @param p_sckSocket Socket to wrap
     *
     */

    public SocketWrapper(Socket p_sckSocket)
    {
        // Save socket passed
        m_sckSocket = p_sckSocket;

        // Create the Input and Output Streams
        createStreams();
    }

    /**
     * Constructor - Creates a socket from host name and port number passed.
     *
     * @param p_sHost String Host name
     * @param p_nPort Integer Port Number
     *
     */

    public SocketWrapper(String p_sHost, int p_nPort)
    {
        // Save Host Name and Port Number
        m_sHost = p_sHost;
        m_nPort = p_nPort;

        // Call the method to create the socket
        createSocket(m_sHost, m_nPort);
    }

   /**
     * setHost - Sets the Hostname
     *
     * @param p_sHost String with Hostname
     *
     */

     public void setHost (String p_sHost)
     {
	m_sHost = p_sHost;
	return;
     }

     /**
      * getHost = get the host name
      *
      * @return String Host Name
      *
      */

    public String getHost ()
    {
	return m_sHost;
    }

    /**
     * setPort - set the port number
     *
     * @param p_nPort Port Number
     *
     */

    public void setPort (int p_nPort)
    {
	m_nPort = p_nPort;
	return;
    }

    /**
     * getPort - returns the port number
     *
     * @return Port Number
     *
     */

    public int getPort ()
    {
	return m_nPort;
    }

     /**
      * setTimeout - Set the timeout for the recieve
      *
      * @param p_nTimeout - Integer Timeout value in milliseconds
      *
      */

      public void setTimeout (int p_nTimeout)
      {
        // Save timeout value
         m_nTimeout = p_nTimeout;

        // Only set socket timeout if socket exists
         if (m_sckSocket != null)
         {
            try
            {
               // Set socket Timeout
               m_sckSocket.setSoTimeout(m_nTimeout);
            }
            catch (SocketException e)
           {
               System.out.println("Socket error occurred: " + e);
           }
         }

         return;
      }

      /**
       * getTimeout - get timeout value
       *
       * @return Integert value of timeout in milliseconds
       *
       */

      public long getTimeout ()
      {

         // Only try to get timeout if socket exists
         if (m_sckSocket != null)
         {
            try
            {
               return m_sckSocket.getSoTimeout();
            }
            catch (SocketException e)
            {
               System.out.println("Socket error: " + e);
               return 0;
            }
          }
          else
          {
              return 0;
          }
      }


    /**
     * createSocket - Creates a socket, using Host Name and Port Number set by
     * the Client.
     *
     */

     public void createSocket ()
     {
	// Call the create socket
	createSocket (m_sHost, m_nPort);

	return;
     }

    /**
     * createSocket - Creates a socket
     *
     * @param p_sHost String Host Name
     * @param p_nPort Integer Port Number
     *
     */

     private void createSocket (String p_sHost, int p_nPort)
     {
	try
	{
	    // Create Socket
            // First create an unconnected socket, so don't have to wait for a socket
            // This can block indefinately
            m_sckSocket = new Socket (p_sHost, p_nPort);

            // A better way to do this <-- Implement at later date
	    // m_sckSocket = new Socket ();
            //m_sckSocket.connect (new InetSocketAddress (p_sHost, p_nPort));

            // Set timeout
            if (m_nTimeout != 0)
            {
                setTimeout(m_nTimeout);
            }

	    // Setup Input and Output Stream
            createStreams();
	}
	catch (Exception e)
	{
	    System.out.println("Error creating socket..." + e);
	    System.exit(-1);
	}

	return;

     }
    /**
     * createStreams - Creates Input and Output Streams
     */

     private void createStreams ()
     {
	try
	{
	    // Setup Input Stream
            m_brInput = new BufferedReader(new InputStreamReader(m_sckSocket.getInputStream()));

            // Setup Output Stream
            m_psOutput = new PrintStream (m_sckSocket.getOutputStream());
	}
	catch (Exception e)
	{
	    System.out.println("Error creating stream..." + e);
	    System.exit(-1);
	}

	return;

     }
    /**
     * sendData - sends data to the socket
     *
     * @param p_sSendData String Data to send
     *
     */

     public void sendData (String p_sSendData)
     {
	// Send the data
	try
	{
	    m_psOutput.println(p_sSendData);
	}
	catch (Exception e)
	{
	    System.out.println("Error sending data: " + e);
	}

	return;
     }

     /**
      * getData - gets data from the socket server
      *
      * *** WARNING : This method blocks until data is received.
      *
      * @return String data
      *
      */

      public String getData ()
      {
	String sTemp = "";       // Temporary buffer

	try
	{
	    // Read a line of data and trim off excess
	    sTemp = m_brInput.readLine().trim();
	}
        catch (InterruptedIOException e)
	{
	    System.out.println("Timeout error, timeout = " + getTimeout() + " Error = " + e);
            System.exit(-1);
	}
	catch (NullPointerException e)
	{
            // Null could be used for end of data
            return null;
	}
	catch (Exception e)
	{
	    System.out.println("Error receiving data: " + e);
            System.exit(-1);
	}

	return sTemp;
      }

      /**
       * closeSocket - Closes the socket
       *
       */

       public void closeSocket ()
       {
	    try
	    {
	        // close the streams
		m_brInput.close();
		m_psOutput.close();

		// Close the socket
		m_sckSocket.close();
	    }
	    catch (Exception e)
	    {
		System.out.println("Error closing socket: " + e);
		System.exit(-1);
	    }

       }

}