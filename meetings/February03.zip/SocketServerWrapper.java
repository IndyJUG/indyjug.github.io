package genericsocketserver;

/**
 * Title: Socket Server Wrapper
 * Description:  A Socket Server wrapper to abstract the socket interfaces
 * Copyright:    Copyright (c) 2003
 * Company:  Indianapolis Java User Group
 * @author Kurt Erik Kirkham
 * @version 1.0
 */

import java.net.*;
import java.io.*;

/**
 *  Socket Server Wrapper to wrap java.net.SocketServer
 */

public class SocketServerWrapper
{

    // Define Class variables
    private ServerSocket servSock = null;          // Temporary Server Socket
    private int m_nPort = 1123;                    // Port Number, df =1123
    private Socket tempSock = null;                // Temporary holder for socket
    private SocketWrapper swSocket = null;         // Socket Wrapper

    /**
     * Constructor
     */

    public SocketServerWrapper()
    {

    }

    /**
     * Constructor - Sets port number
     *
     * @param p_nPort Integer Port number
     *
     */
    public SocketServerWrapper(int p_nPort)
    {
        m_nPort = p_nPort;

    }

    /**
     * startSocketServer - Starts the Socket Server
     */

    public void startSocketServer()
    {
	System.out.println("Attempting to start Server...");
        try
	{
	    // Creates a server socket, bound to the specified port.
            servSock = new ServerSocket(m_nPort);
         }
	catch (Exception e)
	{
            System.out.println("Could not initialize. Exiting.");
            System.exit(1);
        }
	System.out.println("Server successfully initialized on socket = "
			    // Returns the implementation address and
			    // implementation port of this socket as a String.
			    + servSock.toString()
			    + ".  Waiting for connection...");

    }

    /**
     * acceptSocket - Accepts the request from the client.
     *
     * @return SocketWrapper a wrapper around the socket from the client
     *
     */
    public SocketWrapper acceptSocket ()
    {

	try
	{
	    // Listens for a connection to be made to this socket and accepts it.
	    tempSock = servSock.accept();
	    System.out.println("Received New Connection:" + tempSock.getLocalAddress()
            + " port: " + tempSock.getLocalPort() + " Inet: " + tempSock.getInetAddress());

            // Create a new Socket Wrapper
            swSocket = new SocketWrapper (tempSock);
       }
	catch (Exception e)
	{
            System.out.println("New Connection Failure.  Exiting.");
            System.exit(1);
        }

	return swSocket;
    }

    /**
     * closeSocketServer - Closes the Socket Server
     */

    public void closeSocketServer ()
    {
	try
	{
	    // Closes this socket server.
	    servSock.close();
	}
	catch(Exception e)
	{
	    System.out.println("Error shutting down server..." + e);
	    System.exit(-1);
	}

        // Set to null for Garbage Collection
	servSock = null;
    }

    /**
     * setPort - Set the port number
     *
     * @param p_nPort Integer Port number
     *
     */

    public void setPort (int p_nPort)
    {
	m_nPort = p_nPort;
	return;
    }

    /**
     * getPort - Get the port number
     *
     * @return Integer Port number
     *
     */

    public int getPort ()
    {
	return m_nPort;
    }

}