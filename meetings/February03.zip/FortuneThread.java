package fortunecookie;

/**
 * Title:  Detailed Thread
 * Description:  Low level thread to work with the socket
 * Copyright:    Copyright (c) 2003
 * Company:  Indianapolis Java User Group
 * @author Kurt Kirkham
 * @version 1.0
 */

import genericsocketserver.*;

public class FortuneThread extends Thread
{

  // Define Class Variable
  SocketWrapper m_swSocket = null;          // GenericSocket to communicate with

  private boolean m_bClientDone = false;    // Client Done Flag

  // Define Cookie Sayings
  String m_arsCookieSayings[] = {"Dogs rule the rest drool!",
	                         "Help me, I'm trapped in a Chinese Fortune Cookie factory",
				 "You will soon travel to a distant land",
				 "You will find your true love on flag day",
				 "Keeping mouth shut is the path to wisdom",
				 "It is smarter to buy insurance than depend on luck",
				 "Something special is coming your way",
				 "The best cure for envy is to try to get what you want",
				 "A friend will give you a new idea",
				 "Do not confuse what is valuable with what is merely difficult"
				 };


  public FortuneThread(SocketWrapper p_swSocket)
  {
     // Set Generic Socket
     m_swSocket = p_swSocket;

  }

  public void run()
  {
	String sInput = "";             // Input String
	double dRandom = 0;             // Random Number
	int nChoice = 0;                // Pointer to Fortune Cookie

    // Initialize Client Done Flag
    m_bClientDone = false;

    // Do until the client is done
    while (! m_bClientDone)
    {
        // Get the request from the client
        // ** WARNING ** this request blocks
        sInput = m_swSocket.getData();
        System.out.println("Received: " + sInput);

        if (sInput.equals("Command::Bye"))
        {
            // Client is done, set Client Done flag to done
	    m_bClientDone = true;
         }
        else if (sInput.equals("Command::Get"))
        {
            // Get a random Cookie Saying
	    dRandom = Math.random() * m_arsCookieSayings.length;
	    nChoice = (int) dRandom;

            // Send the Random Cookie Saying to the Client
	    m_swSocket.sendData(m_arsCookieSayings[nChoice]);
        }

    }

    // Cleanup and end the thread
    this.finalize();

  }

  public void finalize()
  {
      // Close the socket
      m_swSocket.closeSocket();
  }
}