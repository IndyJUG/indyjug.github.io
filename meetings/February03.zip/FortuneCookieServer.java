package fortunecookie;

/**
 * Title: Fortune Cookie Server
 * Description: A socket server for a fortune cookie set of sayings
 * Copyright:    Copyright (c) 2003
 * Company: Indianapolis Java User Group
 * @author Kurt Erik Kirkham
 * @version 1.0
 */

import genericsocketserver.*;

public class FortuneCookieServer
{

   /**
    * main - main processing of the server
    *
    * The protocol used is:
    *
    * Command::Actions
    *
    * The possible actions are:
    *
    * Get = Give me a cookie!!!
    * Bye = The requestor is done!
    *
    */

    public static void main (String[] args)
    {
        // Define Class Variables
	boolean bShutDown = false;      // Are we done with server yet?

        SocketWrapper gsSocket = null;  // Holder for Generic Socket
        FortuneThread ftThread = null;  // Holder for Fortune Thread

	// Instanciate the Generic Socket Server
	SocketServerWrapper sswSocketServer = new SocketServerWrapper();

	// Set the port to listen on
	sswSocketServer.setPort(1123);

        // Start the socket Server
	sswSocketServer.startSocketServer();

	while (! bShutDown)
	{
	    // Get Connection from the socket server, it returns a generic
            // Socket to communicate with
	    // *** WARNING: This blocks waiting for a connection
            gsSocket = sswSocketServer.acceptSocket();

            // Instanciate a new Fortune Thread
            ftThread = new FortuneThread (gsSocket);
            ftThread.start();
 	}

	// Stop the socket server
	sswSocketServer.closeSocketServer();
	sswSocketServer = null;

    }

}