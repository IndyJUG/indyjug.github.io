package fortunecookieclient;

/**
 * Title: Fortune Cookie Client
 * Description:  A Client for the Fortune Cookie example
 * Copyright:    Copyright (c) 2003
 * Company: Indianapolis Java User Group
 * @author Kurt Erik Kirkham
 * @version 1.0
 */

import genericsocketserver.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class FortuneCookieClient
{

    public static void main(String[] args)
    {
       // Setup and display the Frame
       JFrame frmFrame = new ListFrame();
       frmFrame.setDefaultCloseOperation(frmFrame.EXIT_ON_CLOSE);
       frmFrame.show();
    }


static class ListFrame extends JFrame
{

    // Define Class variables
    JLabel lblFortune = new JLabel ("Your fortune:");
    JTextField txtFortune = new JTextField(60);
    JButton btnGet = new JButton("Get Fortune");
    JButton btnStop = new JButton("Stop");

     public ListFrame()
    {
	Container cpPane = getContentPane();
	cpPane.setLayout(new FlowLayout());
	cpPane.add(lblFortune);
	cpPane.add(txtFortune);
	cpPane.add(btnGet);
        cpPane.add(btnStop);
	ActionListener listener = new ButtonListener();
	btnGet.addActionListener(listener);
        btnStop.addActionListener(listener);

        setTitle("Fortune Cookie Client");
	setSize(800, 100);
    }


class ButtonListener implements ActionListener
{

    SocketWrapper swSocket = null;          // Generic Socket
    boolean bSocketCreated = false;         // Socket Created Flag

     public void actionPerformed (ActionEvent ae)
    {

      if (bSocketCreated == false)
      {
          // Socket does not exist, so create one
          swSocket = new SocketWrapper("Wildwolf4", 1123);
          bSocketCreated = true;
      }

      if (ae.getActionCommand().equalsIgnoreCase("Get Fortune"))
      {
        // Client wants a fortune, send a Get command and wait for the result
        swSocket.sendData("Command::Get");
        txtFortune.setText(swSocket.getData());
      }
      else
      {
         // Default to shutting down the socket, send Bye command
         swSocket.sendData("Command::Bye");

         // Close Socket
         swSocket.closeSocket();

         // Set to null for Garbage Collection
         swSocket = null;

         // Reset variables so can establish socket
         bSocketCreated = false;
         txtFortune.setText("Socket Closed - can close window now");
       }

    } // end actionPerformed

} // end ButtonListener Class
} // end ListFrame Class
} // End FortuneCookieClass