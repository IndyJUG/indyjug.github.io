// This is a program created by Kurt Kirkham for the IndyJUG 3D presentation

// The steps to create a Java 3D program are:

// 1.  Create Canvas3D to display the scene

// 2.  Create SimpleUniverse to manage the basic scene graph; 
//     attach the Canvas3D to the SimpleUniverse

// 3.  Create the content branch to describe the scene to be 
//     rendered and connect to the SimpleUniverse

// 4.  When done, remove all Locales from SimpleUniverse

// Imports for GUI Support
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Imports for Java 3d
import javax.media.j3d.*;                          // for Canvas3D              <==*
import com.sun.j3d.utils.universe.*;               // for SimpleUniverse        <==*
import com.sun.j3d.utils.geometry.Sphere;         // <==*
import javax.vecmath.*;                            // <==*

// Imports for Viewing Platform behaviors
import com.sun.j3d.utils.behaviors.vp.*;
import com.sun.j3d.utils.behaviors.keyboard.*;

// For textures
import com.sun.j3d.utils.image.TextureLoader;

/**
 * Class to test Java3D in a JFrame
 */

public class Kurt3D extends JFrame
{

   // Add Class variables for 3D
   SimpleUniverse suUniverse = null;

   // Add GUI Class Variables
   Container cpPane;                             // Container

   /**
     *  Constructor
     */ 
 
   public Kurt3D ()
   {
      // Call GUI Initialization
      initGUI();
   }


   /**
    * initGUI
    */

   public void initGUI()
   {
        // Get the content pane
        cpPane = this.getContentPane();

        // Set the layout manager
        cpPane.setLayout(new BorderLayout());

        // Set the size
        setSize(1200, 700);
     
       // Set the title
       setTitle("Kurts 3D Demo"); 

       // Add the java 3D stuff
       add3DStuff();                                                       // <==*


     // Set to exit on close
      addWindowListener(
         new WindowAdapter()
             {
                public void windowClosing(WindowEvent e)
                {
                   // 4.  When done, remove all Locales from SimpleUniverse
                       // Close Java 3D stuff
                       suUniverse.removeAllLocales();                                       // <==*
                   // Hide dialog
                   System.exit(0);
                }
             }
      );
  
       // Show the Frame
       setVisible(true);

   }


   /**
    * add3DStuff - add the Java 3D stuff to make it easier to read
    */

   public void add3DStuff()
   {

     // 1.  Create Canvas3D to display the scene

        // Get the Graphics Configuration for the Java 3D Canvas
        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
        
        // Create and Add the 3D Canvas to the Frame
        Canvas3D cvs3D = new Canvas3D(config);
        cpPane.add(BorderLayout.CENTER, cvs3D);
  
     // 2.  Create SimpleUniverse to manage the basic scene graph; 
     //     attach the Canvas3D to the SimpleUniverse

         // Create a simple scene and attach to the Virtual Universe
         // Pass the canvas to the Simple Universe
         suUniverse = new SimpleUniverse(cvs3D);
 
	// add the behaviors to the ViewingPlatform
	ViewingPlatform viewingPlatform = suUniverse.getViewingPlatform();

	// Move the ViewPlatform back, so can view objects
 	viewingPlatform.setNominalViewingTransform();

	// add orbit behavior to ViewingPlatform
	OrbitBehavior orbit = new OrbitBehavior(cvs3D, OrbitBehavior.REVERSE_ALL |
				  OrbitBehavior.STOP_ZOOM);
	BoundingSphere bounds =
	    new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0);

	orbit.setSchedulingBounds(bounds);
	viewingPlatform.setViewPlatformBehavior(orbit);

 


     // 3.  Create the content branch to describe the scene to be 
     //     rendered and connect to the SimpleUniverse

              
         BranchGroup scene = createSceneGraph();
         suUniverse.addBranchGraph(scene);

   }

   
    public BranchGroup createSceneGraph() {

       // Planet Sizes
       float szSun     = 3.0f;
       float szEarth   = szSun * 0.3f;


       // Planet distances
       float distEarth = szSun * 2.0f + 2.0f;                    // 1 au

    
       // Colors
       Color3f clrBlack    = new Color3f(0.0f, 0.0f, 0.f);
       Color3f clrYellow   = new Color3f(1.0f, 1.0f, 0.0f);
       Color3f clrBlue     = new Color3f(0.0f, 0.0f, 1.f);
       Color3f clrWhite    = new Color3f(1.0f, 1.0f, 1.0f);
       Color3f clrRed      = new Color3f(1.0f, 0.0f, 0.0f);

       Color3f eColor    = new Color3f(0.0f, 0.0f, 0.0f);
       Color3f sColor    = new Color3f(1.0f, 1.0f, 1.0f);
       Color3f objColor  = new Color3f(0.6f, 0.6f, 0.6f);


       java.net.URL texImage = null;

    
	// Create the root of the branch graph
	BranchGroup objRoot = new BranchGroup();

        // Create a Transformgroup to scale all objects so they
        // appear in the scene.
        TransformGroup objScale = new TransformGroup();
        Transform3D t3d = new Transform3D();


        // Set scale to fit planets in view platform
	t3d.setScale(0.1);
        objScale.setTransform(t3d); 
        objRoot.addChild(objScale);

        //****************
        // Add the SUn
        //****************

        // Parms for material - Ambient light (reflected), emissive color (emitted light), 
        // Specular color (Highlights), shininess
	Material mSun = new Material(clrYellow, clrYellow, clrWhite, sColor, 100.0f);
	Appearance aSun = new Appearance();
	aSun.setMaterial(mSun);
	Sphere sphSun = new Sphere(szSun, Sphere.GENERATE_NORMALS, 80, aSun);
  
        //Add to scale object, since no transformations will be done on the sun
        objScale.addChild(sphSun);


        //****************
        // Light for sun
        //****************

        BoundingSphere infinateSphere = new BoundingSphere (new Point3d (), Double.MAX_VALUE);

        Point3f sunPosition = new Point3f (0.0f, 0.0f, 0.0f);
        Point3f sunAttenunation = new Point3f (0.0f, 0.0f, 1.0f);

        PointLight sunlight = new PointLight (clrWhite, sunPosition, sunAttenunation);
        sunlight.setInfluencingBounds(infinateSphere);

        objRoot.addChild(sunlight);


        //****************
        // Add the earth
        //****************


        // Transform Group to rotate the earth on its own axis
	TransformGroup transRotEarth = new TransformGroup();
	transRotEarth.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	objScale.addChild(transRotEarth);

        // Transform Group to rotate the earth around the sun
	TransformGroup transRotEarthSun = new TransformGroup();
	transRotEarthSun.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	transRotEarth.addChild(transRotEarthSun);

        // Transform to position the earth away from 0, 0, 0
        Transform3D tPosEarth = new Transform3D();

        Vector3d posEarth =  new Vector3d(-1 * distEarth, 0.0, 0.0);
	tPosEarth.set(posEarth);
        TransformGroup transPosEarth = new TransformGroup(tPosEarth);       
        transPosEarth.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

        transRotEarthSun.addChild(transPosEarth);

        TransformGroup transEarth = new TransformGroup();
        transEarth.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

         // the path to the image file for an application
        if (texImage == null) {
	    // the path to the image for an applet
	    try {
	        texImage = new java.net.URL(                 // [for applets] getCodeBase().toString() +
					  "file:earth.jpg");
	    }
	    catch (java.net.MalformedURLException ex) {
	        System.out.println(ex.getMessage());
		System.exit(1);
	    }
	}

       Appearance aEarth = new Appearance();

        // Set up the texture map
        TextureLoader tex = new TextureLoader(texImage, this);

 
	aEarth.setTexture(tex.getTexture());

	// Set up the material properties
        Material mEarth = new Material(clrWhite, clrBlack, clrWhite, clrBlack, 1.0f);
	mEarth.setLightingEnable(true);
	aEarth.setMaterial(mEarth);
	TextureAttributes texAttr = new TextureAttributes();
	texAttr.setTextureMode(TextureAttributes.MODULATE);
	aEarth.setTextureAttributes(texAttr);


       // Create a Sphere object, generate one copy of the sphere,
       // and add it into the scene graph.

	Sphere sphEarth = new Sphere(szEarth, Sphere.GENERATE_NORMALS | 
				       Sphere.GENERATE_TEXTURE_COORDS, 
				       3*8 + 4, aEarth);


	// Create a new Behavior object that will perform the desired
	// operation on the specified transform object and add it into
	// the scene graph.



	transEarth.addChild(sphEarth);
        transPosEarth.addChild(transEarth);

	// Create a new Behavior object that will perform the
	// desired operation on the specified transform and add
	// it into the scene graph.
  	Transform3D yAxis = new Transform3D();
	Alpha rotationAlpha = new Alpha(-1, 4000);

	RotationInterpolator rotator =
	    new RotationInterpolator(rotationAlpha, transEarth, yAxis,  
				     0.0f, (float) Math.PI*2.0f);
	BoundingSphere bounds =
            new BoundingSphere(new Point3d(0.0,0.0,0.0), 100.0);
	rotator.setSchedulingBounds(bounds);
	transRotEarth.addChild(rotator);   // transposearth

	// Create a new Behavior object that will perform the desired
	// rotation on the specified transform object and add it into
	// the scene graph.
	Transform3D yAxis1 = new Transform3D();
	yAxis1.rotY(Math.PI/2.0);

        // Create a timer with a sawtooth pattern increasing every 10 seconds
        Alpha tickTockAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE,
				     0, 0,
				     10000, 0, 0,
				     0, 0, 0);
	RotationInterpolator tickTock =
	    new RotationInterpolator(tickTockAlpha, transRotEarth, yAxis1,   
                                      0.0f, 
				   // -(float) (Math.PI/2.0f) * 2,
				     (float) (Math.PI/2.0f) * 4);
	tickTock.setSchedulingBounds(bounds);
	transRotEarthSun.addChild(tickTock);


        // Set up the background
        Background bgNode = new Background(clrBlack);
        bgNode.setApplicationBounds(bounds);
        objRoot.addChild(bgNode);


        // Have Java 3D perform optimizations on this scene graph.
        objRoot.compile();


	return objRoot;
    }

   /**
    * Main
    */   


   public static void main (String[] args)
   {
     // Instanciate class to avoid messy static declarations
     Kurt3D obj3D = new Kurt3D();

   }

} 