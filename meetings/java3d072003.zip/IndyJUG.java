// This is a program created by Kurt Kirkham for the IndyJUG 3D presentation

// The steps to create a Java 3D program are:

// 1.  Create Canvas3D to display the scene

// 2.  Create SimpleUniverse to manage the basic scene graph; 
//     attach the Canvas3D to the SimpleUniverse

// 3.  Create the content branch to describe the scene to be 
//     rendered and connect to the SimpleUniverse

// 4.  When done, remove all Locales from SimpleUniverse

// Imports for GUI Support
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Imports for Java 3d
import javax.media.j3d.*;                          // for Canvas3D              <==*
import com.sun.j3d.utils.universe.*;               // for SimpleUniverse        <==*
import com.sun.j3d.utils.geometry.*;               // for geometries            <==*
import javax.vecmath.*;                            // for vector math           <==*
import java.awt.font.*;

// Applet converstion
import com.sun.j3d.utils.applet.MainFrame;

/**
 * Class to test Java3D in a Applet
 */

public class IndyJUG extends Applet
{

   // Add Class variables for 3D
   SimpleUniverse suUniverse = null;
   private double tessellation = 0.0;



   /**
    * initGUI
    */

   public void init()
   {
  
        // Set the layout manager
        setLayout(new BorderLayout());

       // Add the java 3D stuff
       add3DStuff();                                                       // <==*

 
   }


   /**
    * add3DStuff - add the Java 3D stuff to make it easier to read
    */

   public void add3DStuff()
   {

     // 1.  Create Canvas3D to display the scene

        // Get the Graphics Configuration for the Java 3D Canvas
        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
        
        // Create and Add the 3D Canvas to the Frame
        Canvas3D cvs3D = new Canvas3D(config);
        add(BorderLayout.CENTER, cvs3D);
  
     // 2.  Create SimpleUniverse to manage the basic scene graph; 
     //     attach the Canvas3D to the SimpleUniverse

         // Create a simple scene and attach to the Virtual Universe
         // Pass the canvas to the Simple Universe
         suUniverse = new SimpleUniverse(cvs3D);
 
         // Move the ViewPlatform back, so can view objects
         suUniverse.getViewingPlatform().setNominalViewingTransform();


     // 3.  Create the content branch to describe the scene to be 
     //     rendered and connect to the SimpleUniverse

              
         BranchGroup scene = createSceneGraph();
         suUniverse.addBranchGraph(scene);

   }

   
    public BranchGroup createSceneGraph() 
    {

        // Define Colors
        Color3f eColor    = new Color3f(0.0f, 0.0f, 0.0f);
	Color3f sColor    = new Color3f(0.89f, 0.79f, 0.0f);
	Color3f objColor  = new Color3f(0.49f, 0.39f, 0.0f);

        // Define strings to place in Text3D Shape3D objects
        String textString  = "Welcome to IndyJUG!";
        String textString2 = "www.indyjug.net";

        // Get the lengths for the strings to use to place view platform
	float sl = textString.length();
        float s2 = textString2.length();

	// Create the root of the branch graph
	BranchGroup objRoot = new BranchGroup();
 

        // Create a Transformgroup to scale all objects so they
        // appear in the scene.
        TransformGroup objScale = new TransformGroup();
        Transform3D t3d = new Transform3D();
        // Assuming uniform size chars, set scale to fit string in view
	t3d.setScale(1.2/sl);
        objScale.setTransform(t3d);
        objRoot.addChild(objScale);

        //*******
        //* Create first string that rotates around 0,0,0

	// Create the TransformGroup node and initialize it to the
	// identity. Enable the TRANSFORM_WRITE capability so that
	// our behavior code can modify it at run time. Add it to
	// the root of the subgraph.
	TransformGroup transRotText1 = new TransformGroup();
	transRotText1.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	objScale.addChild(transRotText1);

	// Create a simple Shape3D node; add it to the scene graph.
        Font font = new Font (null, Font.PLAIN, 2);
        Font3D fnt3D = new Font3D(new Font("TimesRoman", Font.PLAIN, 2),
		       new FontExtrusion());

        Text3D txt3D = new Text3D (fnt3D, textString, new Point3f( -sl/2.0f, -1.f, -1.f));

        Shape3D shText1 = new Shape3D();
        shText1.setGeometry(txt3D);
	

        Appearance appText1 = new Appearance ();
	Material mText1 = new Material();
	mText1.setLightingEnable(true);
	appText1.setMaterial(mText1);

        shText1.setAppearance(appText1);

        transRotText1.addChild(shText1);


	// Create a new Behavior object that will perform the
	// desired operation on the specified transform and add
	// it into the scene graph.

        BoundingSphere bounds =
	  new BoundingSphere(new Point3d(0.0,0.0,0.0), 100.0);


	Transform3D yAxis = new Transform3D();
	Alpha rotationAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE,
				  0, 0,
				  4000, 0, 0,
				  0, 0, 0);

         RotationInterpolator rotator =
	      new RotationInterpolator(rotationAlpha, transRotText1, yAxis,
				       0.0f, (float) Math.PI*2.0f);

          rotator.setSchedulingBounds(bounds);


	  transRotText1.addChild(rotator);

        //**************
        //* Add Text 2
        //**************

	TransformGroup transText2 = new TransformGroup();
	transText2.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	objScale.addChild(transText2);


      Text3D txt3D2 = new Text3D (fnt3D, textString2, new Point3f( -s2/2.0f, -5.f, -5.f));

       Shape3D shText2 = new Shape3D();
       shText2.setGeometry(txt3D2);
	

        Appearance appText2 = new Appearance ();
	Material mText2 = new Material();
	mText2.setLightingEnable(true);
	appText2.setMaterial(mText2);

         shText2.setAppearance(appText2);

        transText2.addChild(shText2);

	  Transform3D xaxis = new Transform3D();
          xaxis.rotZ(360);


	  RotationInterpolator rotator2 =
	      new RotationInterpolator(rotationAlpha, transText2, xaxis,
				       (float) Math.PI*2.0f, 0.0f);

         rotator2.setSchedulingBounds(bounds);


	  transText2.addChild(rotator2);

        //*******************
        //* Add Golden Sphere
        //*******************


	TransformGroup transRotSphere = new TransformGroup();
	transRotSphere.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	objScale.addChild(transRotSphere);

        // Transform to position the earth away from 0, 0, 0
        Transform3D tPosSphere = new Transform3D();

        Vector3d posSphere =  new Vector3d(-9.0, 0.0, 0.0);
	tPosSphere.set(posSphere);
        TransformGroup transPosSphere = new TransformGroup(tPosSphere);       
        transPosSphere.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

        transRotSphere.addChild(transPosSphere);
        // Create a Sphere object, generate one copy of the sphere,
	// and add it into the scene graph.
	Material mSphere = new Material(objColor, eColor, objColor, sColor, 17.0f);
	Appearance aSphere = new Appearance();
	mSphere.setLightingEnable(true);
	aSphere.setMaterial(mSphere);
	Sphere sph = new Sphere(1.0f, Sphere.GENERATE_NORMALS, 80, aSphere);

	transPosSphere.addChild(sph);

	  Transform3D xaxis3 = new Transform3D();
          xaxis3.rotX(360);
	  Alpha rotationAlpha3 = new Alpha(-1, Alpha.INCREASING_ENABLE,
					  0, 0,
					  4000, 0, 0,
					  0, 0, 0);

	  RotationInterpolator rotator3 =
	      new RotationInterpolator(rotationAlpha3, transRotSphere, xaxis3,
				       0.0f, (float) Math.PI*2.0f);

        rotator3.setSchedulingBounds(bounds);


	  transRotSphere.addChild(rotator3);

        //************************
        //* Add environment nodes
        //************************


        // Set up the background
        Color3f bgColor = new Color3f(0.05f, 0.05f, 0.5f);
        Background bgNode = new Background(bgColor);
        bgNode.setApplicationBounds(bounds);
        objRoot.addChild(bgNode);

        // Set up the ambient light
        Color3f ambientColor = new Color3f(0.1f, 0.1f, 0.1f);
        AmbientLight ambientLightNode = new AmbientLight(ambientColor);
        ambientLightNode.setInfluencingBounds(bounds);
        objRoot.addChild(ambientLightNode);

        // Set up the directional lights
        Color3f light1Color = new Color3f(1.0f, 1.0f, 0.9f);
        Vector3f light1Direction  = new Vector3f(4.0f, -7.0f, -12.0f);
        Color3f light2Color = new Color3f(0.3f, 0.3f, 0.4f);
        Vector3f light2Direction  = new Vector3f(-6.0f, -2.0f, -1.0f);

        DirectionalLight light1
            = new DirectionalLight(light1Color, light1Direction);
        light1.setInfluencingBounds(bounds);
        objRoot.addChild(light1);

        DirectionalLight light2
            = new DirectionalLight(light2Color, light2Direction);
        light2.setInfluencingBounds(bounds);
        objRoot.addChild(light2);


        // Have Java 3D perform optimizations on this scene graph.
        objRoot.compile();

	return objRoot;
    }
    
    /**
    * Destroy applet
    */

    public void destroy()
    {
         // Close Java 3D stuff
         suUniverse.removeAllLocales();  
    }

   /**
    * Main
    */   


   public static void main (String[] args)
   {
     // Instanciate class to avoid messy static declarations
     MainFrame objMF = new MainFrame(new IndyJUG(), 1200, 700);

   }

} 