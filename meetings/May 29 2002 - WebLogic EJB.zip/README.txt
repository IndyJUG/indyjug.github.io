Indianapolis Java Users Group
May 29, 2002
Jeff Block, Regional Readiness Field Engineer
WorldWide Technical Readiness -- US Central Region
BEA Systems, Inc. (www.bea.com)
Email: jblock@bea.com 

This file contains the presentation from the JUG meeting, as well as a few demo files I put together and the custom modifications I've made to the standard WebLogic Server 6.1 Examples domain installed with the app server.  The following loosely explains installation of the ejb example I created; please don't hesitate to contact me with more specific questions...

1) Replace the following files 

	A) Replace %WLS_HOME%/config/examples/startExamplesServer.cmd with %ZIP%/ejbdemo/weblogic/startExamplesServer.cmd
	B) Replace %WLS_HOME%/config/examples/config.xml with %ZIP%/ejbdemo/weblogic/config.xml
	C) Copy %ZIP%/ejbdemo/build/ejbdemo.jar to %WLS_HOME%/config/examples/applications

2) Start WebLogic Server with the newly-modified startExamplesServer.cmd

Have fun!