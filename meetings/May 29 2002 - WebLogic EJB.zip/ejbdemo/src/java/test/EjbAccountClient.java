import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;
import javax.naming.*;

import examples.ejb.basic.containerManaged.*;

public class EjbAccountClient
{
    private static String _url = "t3://localhost:7001";
    private static String _ctx = "weblogic.jndi.WLInitialContextFactory";

	public static void main (String[] args) {
		new EjbAccountClient().execute();
	}

	private void execute() {
		try {
			String jndiName = "containerManaged.AccountHome";
			String accountID = "123";
			long accountBalance = 1000;
			String accountType = "savings";


			Properties p = new Properties();
			p.put(Context.INITIAL_CONTEXT_FACTORY, _ctx);
			p.put(Context.PROVIDER_URL, _url);
			Context ctx = new InitialContext(p);

			AccountHome home = (AccountHome)ctx.lookup(jndiName);
			Account account = home.create(accountID, accountBalance, accountType);

			System.out.println("Type: " + account.accountType());
			System.out.println("Balance: " + account.balance());

			System.out.println("Depositing $50");
			account.deposit(50);
			System.out.println("Balance: " + account.balance());

			try {
				System.out.println("Withdrawing $500");
				account.withdraw(50000);
			}
			catch (ProcessingErrorException pe) {
				System.out.println("Exception thrown attempting to withdraw money");
			}
			finally {
				System.out.println("Balance: " + account.balance());
			}
		}
		catch (CreateException ce) {
			System.out.println("Cannot create account");
		}
		catch (RemoteException re) {
			System.out.println("Cannot connect to remote bean");
		}
		catch (NamingException ne) {
			System.out.println("Cannot find account bean in JNDI tree");
		}
	}
}
