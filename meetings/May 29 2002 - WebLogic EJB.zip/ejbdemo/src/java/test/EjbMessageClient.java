package test;

public class EjbMessageClient
{
    private static String QUEUE_NAME = "ejbdemo.jms.AsynchMessages";
	
    private static String _url = "t3://localhost:7001";
    private static String _ctx = "weblogic.jndi.WLInitialContextFactory";

	public static void main (String[] args) {
		new EjbMessageClient().execute();
	}

	private void execute() {
		/*
		try {
			
		}
		catch (CreateException ce) {
			System.out.println("Cannot create account");
		}
		catch (RemoteException re) {
			System.out.println("Cannot connect to remote bean");
		}
		catch (NamingException ne) {
			System.out.println("Cannot find account bean in JNDI tree");
		}
		*/
	}
}
