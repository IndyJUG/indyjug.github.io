package com.beasys.ejbdemo.error;

//java imports
import java.io.Serializable;

/**
 * Indicates an application level error, or recoverable error has occured.
 * This exception (and its subclasses) should be thrown when the application
 * was unable to perform a specific action due to an acceptable reason.  Some
 * 'acceptable' reasons are:
 * <ul>
 * <li>User input was null or invalid
 * <li>Requested object/information does not exist
 * </ul>
 * <p>
 * For example, the NotFoundException extends this exception
 * to indicate that the query did not return any results.  If a user requested 
 * information about a specific 'location' and that location could not be found
 * in the database (data source).
 * <p>
 * 
 * This exception should NOT be used to indicate failures that do not relate to
 * user input or expected failure cases.  For example, if the system is unable to log
 * in to the database or access a required resource, you should use the 
 * <a href="SystemException.html">SystemException</a> class, or one of its subclasses.
 * 
 * @author Eric Daugherty
 */
public class BusinessException extends CascadingException implements Serializable { 
    
	/**
	 * Creates a new exception without any additional information.
	 */
    public BusinessException() {
        super();
    }
    
	/**
	 * Creates a new exception and nests the exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>)
	 * passed in as a parameter.
	 * 
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */	
    public BusinessException( Throwable nextedException ) {
        super( nextedException );
    }
    
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * 
	 * @param msg A message describing the error that occured.
	 */
    public BusinessException( String msg ) {
        super( msg );
    }
    
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * @param msg A message describing the error that occured.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
	public BusinessException( String msg, Throwable nestedException ) {
        super( msg, nestedException );
    }
}

//EOF