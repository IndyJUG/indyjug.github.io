package com.beasys.ejbdemo.envoy;

// Java classes
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.rmi.RemoteException;
import javax.ejb.*;
import javax.naming.*;

// Project classes
import com.beasys.ejbdemo.error.*;

// Bean classes
import com.beasys.ejbdemo.session.*;

/**
 * Abstracted access (using the Business Delegate, or "Envoy", pattern) 
 * to a session EJB.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */ 
public class ExampleEnvoy
{
    /** The JNDI name of this services mapped to this envoy */
    private static String JNDI_NAME = "ejbdemo.HelloWorld";
    
    /** The attribution services bean */
    private static HelloWorld _service = null;

    /** The singleton instance of this envoy */
    private static ExampleEnvoy _instance = null;
    
    /**
     * Default constructor (private as part of the singleton design 
     * patern).  Class cannot be constructed from the outside.  Clients 
     * to this class must call the <code>getInstance</code> method to 
     * obtain an instance.
     *
     * @exception TODO
     *
     * @see #getInstance
     */
    private
    ExampleEnvoy()
	throws SystemException {
		try {
			Context ctx = getInitialContext();
			HelloWorldHome service = (HelloWorldHome)ctx.lookup(JNDI_NAME);
			_service = service.create();
		}
		catch (CreateException ce) {
            throw new SystemException("Some CreateException", ce);
		}
		catch (NamingException ne) {
            throw new SystemException("Some NamingException", ne);
		}
		catch (RemoteException re) {
            throw new SystemException("Some RemoteException", re);
		}
    }
    
    /**
     * Returns the Singleton instance of this Envoy.  As per 
     * the singleton design pattern, this method insures that
     * only one instance of this object will ever exist.
     *
     * @return The instance of <code>ExampleEnvoy</code>.
     *
     * @exception TODO
     */
    public static 
    ExampleEnvoy getInstance() 
	throws SystemException {
        if (_instance == null) 
            _instance = new ExampleEnvoy();
        return _instance;
    }

    /**
     * @see com.beasys.ejbdemo.session.HelloWorld#getMessage
     */
    public
    String getMessage()
	throws SystemException, BusinessException {
        try {
            return _service.getMessage();
        }
        catch (RemoteException re) {
            throw new SystemException("some RemoteException", re);
        }
        catch (EJBException ejbe) {
            throw new SystemException("some EJBException", ejbe);
        }
    }

    /**
     * Gets the initial (default) context information for the JNDI lookup
     * of the bean associated with this envoy.
     *
     * @return Context information.
     *
     * @exception Exception Thrown if anything goes wrong.
     */
    protected
    Context getInitialContext()
	throws NamingException
    {
        return new InitialContext();
    }

    /**
     * Gets the initial (default) context information for the JNDI lookup
     * of the bean associated with this envoy.
     *
     * @param jndiPropFile The name of a properties file from which to read
     *                     JNDI information.
     *
     * @return Context information.
     *
     * @exception Exception Thrown if anything goes wrong.
     */
    protected
    Context getInitialContext(String jndiPropFile)
	throws IOException, NamingException 
    {
        InputStream is = getClass().getClassLoader().getResourceAsStream(jndiPropFile);

        // Use the class loader to read in a file and populate a properties object
        Properties p = new Properties();
	    p.load(is);
        return new InitialContext(p);
	}

    /**
     * Gets the initial (default) context information for the JNDI lookup
     * of the bean associated with this envoy.
     *
     * @param ctx The JNDI context.
     * @param url The location of the resource.
     *
     * @return Context information.
     *
     * @exception Exception Thrown if anything goes wrong.
     */
    protected
    Context getInitialContext(String ctx, String url)
	throws NamingException 
    {
       	Properties p = new Properties();
       	p.put(Context.INITIAL_CONTEXT_FACTORY, ctx);
       	p.put(Context.PROVIDER_URL, url);
       	return new InitialContext(p);
	}
}

// EOF