package com.beasys.ejbdemo.session;

// Java classes
import javax.ejb.*;
import java.rmi.RemoteException;

/**
 * Home interface of the <code>HelloWorld</code> session EJB.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */ 
public interface HelloWorldHome extends EJBHome
{
	public 
	HelloWorld create()
	throws CreateException, RemoteException;
}

// EOF
