package com.beasys.ejbdemo.error;

//Java imports
import java.io.*;

/**
 * TODO
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public abstract class CascadingException extends Exception implements Serializable 
{
	//***************************************************************
    // Constructors
    //***************************************************************
	
	public 
	CascadingException() {
		super();
    }
    
	public 
	CascadingException( Throwable nextedException ) {
		super();
		_nestedException = nextedException;
    }
    
    public 
	CascadingException( String msg ) {
        super(msg);
    }
	
    public 
	CascadingException( String msg, Throwable nestedException ) {
        this(msg);
        _nestedException = nestedException;
    }
	
	
	//***************************************************************
    // Public Interface
    //***************************************************************

	/**
	 * Provides access to the nested exception stored in this Exception.
	 * 
	 * @return the nestedException that was passeed to this class in the
	 * constructor, or null if none exists.
	 */
    public Throwable getNestedException() {
		return _nestedException;
	}

	/**
	 * Iterates through all the nested CascadingExceptions to genrate the
	 * entire stack trace for the entire tree.
	 * <p>
	 * The resulting stack trace will contain the stack trace from the
	 * 'deepest' exception first.  The last stack trace displayed will 
	 * be the stack trace for this exception.
	 * 
	 * @return String containing the stack trace of the entire cascade of exceptions.
	 */
    public String getStackTrace() {
        
		StringBuffer traceBuffer = new StringBuffer();
		
		if( _nestedException != null ) {
        
			// descend through linked-list of nesting exceptions, & output trace
			// note that this displays the 'deepest' trace first
			if (_nestedException instanceof CascadingException) {
			    
				traceBuffer.append ( ((CascadingException)_nestedException).getStackTrace() );
			}
			else {
				traceBuffer.append ( generateStackTraceString( _nestedException ) );
			}
			
			traceBuffer.append("-------- nested by:\n");
		}

		traceBuffer.append( generateStackTraceString() );
        return traceBuffer.toString();
    }
	
    /**
     * Overrides the Exception.getMessage() method to include the Exception message
     * information from the nested exception.
     * 
     * @return the Exception message from this exception and the nested
     * exception.
     */
    public String getMessage() {
		
		//The String to build.
		StringBuffer retVal = new StringBuffer();
		
        //Add the String Message
        String superMessage = super.getMessage();

		if( superMessage != null && superMessage.length() > 0 ) {
			retVal.append( superMessage );
		}
		
        //Add the Nested Exception's Message
		Throwable nestedException = getNestedException();
		
		//Get the string and check.  If OK, add...
		if ( nestedException != null ) {
			String nestedString = nestedException.toString();
			if ( nestedString != null && nestedString.length() > 0 ) {
				if ( retVal.length() > 0 ) {
					retVal.append("\r\nNestedException: ");
				}
				retVal.append( nestedString );
			}
		}
		
        return retVal.toString();
    }

	/**
	 * Overrides the Exception.printStackTrace() method to print the
	 * entire stack trace for this exception 
     * and the entire cascade of exceptions.
	 */
    public void printStackTrace() {
        System.out.println( getStackTrace() );    
    }
    
	/**
	 * Overrides the Exception.printStackTrace() method to print
	 * the entire stack trace for this exception 
     * and the entire cascade of exceptions to the specified
     * PrintWriter.
     * 
     * @param printWriter - the PrintWriter to write the stack trace to.
	 */
    public void printStackTrace(PrintWriter printWriter) {
        printWriter.print( getStackTrace() );
    }
    
	/**
	 * Overrides the Exception.printStackTrace() method to print
	 * the entire stack trace for this exception 
     * and the entire cascade of exceptions to the specified
     * PrintWriter.
     * 
     * @param printWriter - the PrintStream to write the stack trace to.
	 */
    public void printStackTrace(PrintStream printStream) {
        printStream.print( getStackTrace() );
    }
    
	
	//***************************************************************
    // Private Interface
    //***************************************************************

	/**
	 * Generates the stack trace and returns it as a string.
	 * 
	 * @param throwable the exception to get the stack trace from.
	 */
	private String generateStackTraceString() {
        StringWriter stringWriter = new StringWriter();
        super.printStackTrace( new PrintWriter(stringWriter) );
        return stringWriter.toString();
	}
	
	/**
	 * Generates the stack trace for the given Throwable and returns
	 * it as a string.
	 * 
	 * @param throwable the exception to get the stack trace from.
	 */
    private String generateStackTraceString( Throwable throwable ) {
        StringWriter stringWriter = new StringWriter();
        throwable.printStackTrace( new PrintWriter(stringWriter) );
        return stringWriter.toString();
    }
	
	
	//***************************************************************
    // Private Variables
	//***************************************************************

	/** The nested exception. */
    private Throwable _nestedException;
}

//EOF