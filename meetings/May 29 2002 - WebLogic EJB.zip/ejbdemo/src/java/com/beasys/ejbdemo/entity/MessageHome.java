package com.beasys.ejbdemo.entity;

// Java classes
import java.rmi.RemoteException;
import javax.ejb.*;

/**
 * Home interface of the entity bean, used to retrieve a remote reference
 * to the EJB.  If <code>Create</code> is used, a new message object is 
 * created.  If <code>findByPrimaryKey</code> is used, a lookup is done
 * for an existing message in the database.  Extending 
 * <code>EJBLocalHome</code> would make this a local interface.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public interface MessageHome extends EJBHome
{
	public 
	Message create(String id, String message)
	throws CreateException, RemoteException;
	
	public 
	Message findByPrimaryKey(String key)
	throws FinderException, RemoteException;
}

// EOF