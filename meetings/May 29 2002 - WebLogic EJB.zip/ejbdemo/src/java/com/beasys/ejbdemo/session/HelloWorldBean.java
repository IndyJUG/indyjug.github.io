package com.beasys.ejbdemo.session;

// Java classes
import java.rmi.RemoteException;
import javax.ejb.*;
import javax.naming.*;

// Project classes
import com.beasys.ejbdemo.error.*;

/**
 * The bean implmentation.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public class HelloWorldBean implements SessionBean
{
    public
    String getMessage()
	throws RemoteException {
		return "Hello world!";
    }
    
	//***************************************************************
    // Other (Obligatory) EJB Methods
    //***************************************************************
	
	private SessionContext _ctx;

    public 
	void setSessionContext(SessionContext ctx) 
	throws RemoteException, EJBException {
        _ctx = ctx;
    }
	
    public void ejbCreate() throws CreateException, RemoteException, EJBException {}
	public void ejbActivate() throws RemoteException, EJBException {}
    public void ejbPassivate() throws RemoteException, EJBException {}
    public void ejbRemove() throws RemoteException, EJBException {}
}

// EOF
