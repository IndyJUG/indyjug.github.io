package com.beasys.ejbdemo.entity;

// Java classes
import java.rmi.RemoteException;
import javax.ejb.*;

/**
 * The remote interface for the entity bean.  Extending 
 * <code>EJBLocalObject</code> would make this a local interface.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public interface Message extends EJBObject
{
}

// EOF