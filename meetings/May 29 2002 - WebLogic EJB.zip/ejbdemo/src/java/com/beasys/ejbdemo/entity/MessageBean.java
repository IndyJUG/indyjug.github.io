package com.beasys.ejbdemo.entity;

// Java classes
import java.rmi.RemoteException;
import java.sql.*;
import java.util.Date;
import javax.ejb.*;

/**
 * Implementation of the entity bean.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public abstract class MessageBean implements EntityBean
{
	/**
	 * container managed fields
	 */
	abstract public String getId();
	abstract public void setId(String val);

	abstract public String getMessage();
	abstract public void setMessage(String val);
	
    public 
	String ejbCreate(String id, String message) 
	throws CreateException {
		setId(id);
		setMessage(message);
		return id;
	}
	
	//***************************************************************
    // Other (Obligatory) EJB Methods
    //***************************************************************
	
	private EntityContext _ctx;
	
	public 
	MessageBean() {}
	
    public 
	void setEntityContext(EntityContext ctx)
	throws EJBException, RemoteException {
		_ctx = ctx;
	}

    public 
	void unsetEntityContext()
    throws EJBException, RemoteException {
		_ctx = null;
	}
	
    public void ejbPostCreate(String id, String message) {}
	public void ejbActivate() {}
	public void ejbLoad() {}
	public void ejbStore() {}
    public void ejbPassivate() {}
    public void ejbRemove() {}
}

// EOF
