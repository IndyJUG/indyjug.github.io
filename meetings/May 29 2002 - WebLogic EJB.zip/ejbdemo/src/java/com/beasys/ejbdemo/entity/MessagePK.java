package com.beasys.ejbdemo.entity;

// Java classes
import java.io.Serializable;

public class MessagePK implements Serializable
{
	public long id;
	
	public
	MessagePK() {}
	
	public 
	MessagePK(long id) {
		this.id = id;
	}
	
	public 
	boolean equals(Object obj) {
		if (obj instanceof MessagePK) {
			MessagePK compare = (MessagePK)obj;
			return (id == compare.id);
		}
		return false;
	}
	
	public
	int hashCode() {
		return (int)id;
	}
}

// EOF