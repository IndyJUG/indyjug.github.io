package com.beasys.ejbdemo.mdb;

// Java imports
import java.rmi.RemoteException;
import javax.ejb.*;
import javax.jms.*;

/**
 * The implementation of the bean, which is the only file required to 
 * implement an MDB.
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public class AsynchMessageBean implements MessageDrivenBean
{
    public 
	void onMessage(Message msg) {
        try {
            System.out.println( "AsynchMessageBean msg Received: " + msg.getStringProperty("value") );
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
	//***************************************************************
    // Other (Obligatory) EJB Methods
    //***************************************************************
	
	private MessageDrivenContext _ctx;

    public 
	void setMessageDrivenContext(MessageDrivenContext ctx) 
	throws EJBException {
        _ctx = ctx;
    }
    
    public void ejbCreate() throws CreateException, RemoteException, EJBException {}
    public void ejbRemove() throws EJBException {}
}

// EOF
