package com.beasys.ejbdemo.session;

// Java packages
import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import javax.ejb.EJBException;

// Project classes
import com.beasys.ejbdemo.error.*;

/**
 * TODO
 *
 * @author Jeff Block, BEA WWTR Regional Readiness
 */
public interface HelloWorld extends EJBObject 
{
    public
    String getMessage()
	throws RemoteException;
}

// EOF
