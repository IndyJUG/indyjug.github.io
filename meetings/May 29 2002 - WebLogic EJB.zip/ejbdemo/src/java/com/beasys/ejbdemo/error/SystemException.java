package com.beasys.ejbdemo.error;

//java imports
import java.io.Serializable;

/**
 * Indicates that a serious error has occured and could not be recoved.  
 * This exception (and its subclasses) should be used to indicate errors 
 * that occured interacting with external systems, or when the application
 * is in a state that should never occur.
 * <p>
 * For example, DatabaseException extends this class to encapsulate all 
 * errors that occur interacting with external data stores.
 * <p>
 * Another example is a case where a parameter passed to a method 
 * is null when this is an 'impossible' condition (the method requires the 
 * parameter, and the calling method has broken the contract).  
 * <p>
 * Note, this class should NOT be used to indicate errors in user input, or 
 * other conditions where the user has input information that is invalid.  These
 * types of errors should be handled with the <a href="BusinessException.html">BusinessException</a>
 * class.
 * 
 * @author Eric Daugherty
 */
public class SystemException extends CascadingException implements Serializable { 
    
	/**
	 * Creates a new exception without any additional information.
	 */
    public SystemException() {
        super();
    }
    
	/**
	 * Creates a new exception and nests the exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>)
	 * passed in as a parameter.
	 * 
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */	
    public SystemException( Throwable nextedException ) {
        super( nextedException );
    }
    
	/**
	 * Creates a new exception using the provided message.  No original 
	 * Exception is captured.
	 * 
	 * @param msg A message describing the error that occured.
	 */
    public SystemException( String msg ) {
        super( msg );
    }
    
	/**
	 * Creates a new exception using the provides message and exception 
	 * (<a href="http://java.sun.com/j2se/1.3/docs/api/java/lang/Throwable.html">java.lang.Throwable</a>).
	 * @param msg A message describing the error that occured.
	 * @param nextedException captured as the 'original' exception and used to 
	 * display error message and stacktrace information.
	 */
	public SystemException( String msg, Throwable nestedException ) {
        super( msg, nestedException );
    }
}
//EOF